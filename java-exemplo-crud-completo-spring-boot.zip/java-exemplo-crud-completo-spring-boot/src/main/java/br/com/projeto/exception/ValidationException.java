package br.com.projeto.exception;


public class ValidationException extends Exception{

}
